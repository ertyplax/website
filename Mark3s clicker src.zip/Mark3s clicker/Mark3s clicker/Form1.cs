﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mark3s_clicker
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("User32.Dll", EntryPoint = "PostMessageA")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("User32.dll")]
        public static extern short GetAsyncKeyState(System.Windows.Forms.Keys vKey); // Keys enumeration


        public Form1()
        {
            InitializeComponent();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label1.Text = "PISELLI AL SECONDO: " + trackBar1.Value;
        }

        private async void timer1_Tick(object sender, EventArgs e)
        {
            

            Process[] processes = Process.GetProcessesByName("javaw");
            foreach (Process process in processes)
            {
                if (GetForegroundWindow() == FindWindow(null, process.MainWindowTitle))
                {
                    if (button1.Text == "PISELLO: ON")
                    {
                        if (MouseButtons == MouseButtons.Left)
                        {
                            timer1.Interval = 1000 / trackBar1.Value;

                            SendMessage(GetForegroundWindow(), 0x201, 0, 0);
                            await Task.Delay(1);
                            SendMessage(GetForegroundWindow(), 0x202, 0, 0);
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "PISELLO: OFF")
            {
                timer1.Start();
                button1.Text = "PISELLO: ON";
            }
            else
            {
                timer1.Stop();
                button1.Text = "PISELLO: OFF";
            }
        }
    }
}
